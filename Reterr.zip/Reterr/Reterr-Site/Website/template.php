<?php include 'global.php';?>

<?php include 'footer.php';?>