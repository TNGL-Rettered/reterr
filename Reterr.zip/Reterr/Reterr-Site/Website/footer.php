<div class="container">
<div class="card">
<div class="card-body"><a href="<?php echo SITEDOMAIN;?>" target="_blank"><?php echo SITENAME;?> 2021</a> <div class="card-body">Copyright © <a href="https://corp.roblox.com/" target="_blank">ROBLOX Corporation</a> 2021. We are not affiliated with <a href="https://corp.roblox.com/" target="_blank">ROBLOX Corporation</a>.<br><a href="<?php echo SITEDOMAIN;?>/Legal/Terms.php">Terms of Service</a> | <a href="<?php echo SITEDOMAIN;?>/Legal/Policy.php">Privacy Policy</a> | <a href="https://discord.gg/e9aqvW5eQ4">Discord Server</a></div> 
</div></div>